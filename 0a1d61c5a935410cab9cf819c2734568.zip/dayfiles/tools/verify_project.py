#!/usr/bin/env python3
"""Static project sanity checks; this does not compile or execute the Android app."""
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
ANDROID = "http://schemas.android.com/apk/res/android"

def fail(message: str) -> None:
    print(f"FAIL: {message}")
    sys.exit(1)

def require(path: str) -> Path:
    p = ROOT / path
    if not p.is_file():
        fail(f"missing file: {path}")
    return p

manifest_path = require("app/src/main/AndroidManifest.xml")
manifest = ET.parse(manifest_path).getroot()
permissions = {node.get(f"{{{ANDROID}}}name") for node in manifest.findall("uses-permission")}
if "android.permission.MANAGE_EXTERNAL_STORAGE" not in permissions:
    fail("MANAGE_EXTERNAL_STORAGE is not declared")
if "android.permission.INTERNET" in permissions:
    fail("INTERNET permission should not be declared")

app = manifest.find("application")
if app is None:
    fail("application element missing")
activities = [e for e in app.findall("activity") if e.get(f"{{{ANDROID}}}name") == ".MainActivity"]
if not activities or activities[0].get(f"{{{ANDROID}}}exported") != "true":
    fail("launcher MainActivity is missing or not exported")
providers = [e for e in app.findall("provider") if e.get(f"{{{ANDROID}}}name") == ".FileShareProvider"]
if not providers:
    fail("FileShareProvider missing")
provider = providers[0]
if provider.get(f"{{{ANDROID}}}exported") != "false" or provider.get(f"{{{ANDROID}}}grantUriPermissions") != "true":
    fail("FileShareProvider must be non-exported and grant temporary URI access")

for path in [
    "settings.gradle", "build.gradle", "gradle.properties", "gradle/wrapper/gradle-wrapper.properties",
    "app/build.gradle", "app/proguard-rules.pro", "app/src/main/res/values/styles.xml",
    "app/src/main/java/com/dayfiles/app/MainActivity.java",
    "app/src/main/java/com/dayfiles/app/FileScanner.java",
    "app/src/main/java/com/dayfiles/app/FileIndex.java",
    "app/src/main/java/com/dayfiles/app/FileShareProvider.java",
    "app/src/main/java/com/dayfiles/app/FileTypes.java",
    "app/src/main/java/com/dayfiles/app/FileItem.java",
    "README_RU.md", "TEST_PLAN_RU.md",
]:
    require(path)

ET.parse(ROOT / "app/src/main/res/values/styles.xml")
app_gradle = (ROOT / "app/build.gradle").read_text(encoding="utf-8")
for fragment in ["compileSdk 36", "targetSdk 36", "minSdk 30", "sourceCompatibility JavaVersion.VERSION_17", "androidx.exifinterface:exifinterface:1.4.2"]:
    if fragment not in app_gradle:
        fail(f"app/build.gradle lacks: {fragment}")

scanner = (ROOT / "app/src/main/java/com/dayfiles/app/FileScanner.java").read_text(encoding="utf-8")
for fragment in ["Environment.getExternalStorageDirectory()", "getStorageVolumes()", "readCreationTime", "readCaptureDate", "cancelled.get()", "index.upsertBatch"]:
    if fragment not in scanner:
        fail(f"FileScanner lacks: {fragment}")

index = (ROOT / "app/src/main/java/com/dayfiles/app/FileIndex.java").read_text(encoding="utf-8")
for fragment in ["CREATE TABLE files", "CREATE INDEX idx_files_modified", "LIMIT ", "OFFSET ", "COUNT(*)"]:
    if fragment not in index:
        fail(f"FileIndex lacks: {fragment}")

print("OK: manifest and styles XML parse; required project files, permissions, API levels and core source markers are present.")
print("NOTE: this is a static sanity check only; it does not compile, install or test the Android application.")
