# AndroidX ExifInterface is accessed directly; no custom keep rules are required.
