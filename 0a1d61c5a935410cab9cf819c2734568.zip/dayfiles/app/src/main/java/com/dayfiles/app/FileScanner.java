package com.dayfiles.app;

import android.content.Context;
import android.media.MediaMetadataRetriever;
import android.os.Environment;
import android.os.storage.StorageManager;
import android.os.storage.StorageVolume;

import androidx.exifinterface.media.ExifInterface;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.attribute.BasicFileAttributes;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.TimeZone;
import java.util.concurrent.atomic.AtomicBoolean;

final class FileScanner {
    interface Listener {
        void onProgress(long filesSeen, long filesIndexed, int inaccessible);
        void onFinished(long filesIndexed, int inaccessible, boolean cancelled, String message);
    }

    private static final int BATCH_SIZE = 250;
    private static final Object SCAN_LOCK = new Object();
    private final Context appContext;
    private final FileIndex index;
    private final AtomicBoolean cancelled = new AtomicBoolean(false);
    private volatile boolean forceCaptureDateRefresh;

    FileScanner(Context context, FileIndex index) {
        this.appContext = context.getApplicationContext();
        this.index = index;
    }

    void prepare(boolean forceCaptureDateRefresh) {
        cancelled.set(false);
        this.forceCaptureDateRefresh = forceCaptureDateRefresh;
    }
    void cancel() { cancelled.set(true); }

    void scan(Listener listener) {
        synchronized (SCAN_LOCK) {
            scanLocked(listener);
        }
    }

    private void scanLocked(Listener listener) {
        long scanId = System.nanoTime();
        long seen = 0;
        long indexed = 0;
        int inaccessible = 0;
        long lastProgress = 0;
        ArrayList<FileItem> batch = new ArrayList<>(BATCH_SIZE);
        Set<String> visitedDirectories = new HashSet<>();

        try {
            List<File> roots = storageRoots();
            if (roots.isEmpty()) {
                listener.onFinished(0, 1, false, "Не найден доступный накопитель.");
                return;
            }
            ArrayDeque<File> stack = new ArrayDeque<>();
            for (File root : roots) stack.push(root);

            while (!stack.isEmpty() && !cancelled.get()) {
                File dir = stack.pop();
                String dirPath;
                try {
                    dirPath = dir.getCanonicalPath();
                } catch (IOException | SecurityException e) {
                    inaccessible++;
                    continue;
                }
                if (!visitedDirectories.add(dirPath)) continue;

                File[] children;
                try {
                    children = dir.listFiles();
                } catch (SecurityException e) {
                    inaccessible++;
                    continue;
                }
                if (children == null) {
                    inaccessible++;
                    continue;
                }

                boolean isAndroidDir = "Android".equalsIgnoreCase(dir.getName());
                for (File child : children) {
                    if (cancelled.get()) break;
                    try {
                        if (Files.isSymbolicLink(child.toPath())) continue;
                    } catch (Exception ignored) {
                        // Continue with the ordinary file checks below.
                    }

                    if (child.isDirectory()) {
                        if (isAndroidDir) {
                            // Android/data and Android/obb are blocked by the platform.
                            // Android/media remains part of shared storage and is scanned.
                            if ("media".equalsIgnoreCase(child.getName())) stack.push(child);
                            continue;
                        }
                        if (isBlockedAndroidDirectory(child)) continue;
                        if (child.canRead()) stack.push(child); else inaccessible++;
                    } else if (child.isFile()) {
                        seen++;
                        long modified = child.lastModified();
                        long size = child.length();
                        if (!child.canRead()) {
                            inaccessible++;
                            continue;
                        }

                        String path = child.getAbsolutePath();
                        String name = child.getName();
                        String ext = FileTypes.extension(name);
                        FileIndex.Cached cached = index.getCached(path);
                        long created = Long.MIN_VALUE;
                        long exif = Long.MIN_VALUE;
                        boolean sameFileMetadata = cached != null && cached.size == size && cached.modifiedMs == modified;
                        boolean metadataChanged = true;
                        if (sameFileMetadata) created = cached.createdMs;
                        else created = readCreationTime(child, modified);

                        if (sameFileMetadata && !forceCaptureDateRefresh) {
                            exif = cached.exifMs;
                            metadataChanged = false;
                        } else {
                            exif = readCaptureDate(child, ext);
                        }

                        batch.add(new FileItem(path, name, ext, FileTypes.kind(ext), FileTypes.mime(ext),
                                size, modified, created, exif, metadataChanged));
                        indexed++;
                        if (batch.size() >= BATCH_SIZE) {
                            index.upsertBatch(batch, scanId);
                            batch.clear();
                        }
                    }

                    long now = System.currentTimeMillis();
                    if (now - lastProgress >= 450) {
                        listener.onProgress(seen, indexed, inaccessible);
                        lastProgress = now;
                    }
                }
            }

            if (!batch.isEmpty()) index.upsertBatch(batch, scanId);
            boolean wasCancelled = cancelled.get();
            if (!wasCancelled && inaccessible == 0) {
                // Prune only after a complete, readable pass; otherwise keep cached rows
                // for directories that may have been temporarily inaccessible.
                index.removeUnseen(scanId);
            }
            String message;
            if (wasCancelled) message = "Сканирование остановлено. Частичный индекс сохранён; старые записи не удалены.";
            else if (inaccessible > 0) message = "Индекс частично обновлён. Недоступные каталоги пропущены, старые записи сохранены.";
            else message = "Индекс обновлён.";
            listener.onFinished(indexed, inaccessible, wasCancelled, message);
        } catch (Exception e) {
            if (!batch.isEmpty()) {
                try { index.upsertBatch(batch, scanId); } catch (Exception ignored) {}
            }
            listener.onFinished(indexed, inaccessible + 1, cancelled.get(),
                    "Ошибка сканирования: " + e.getClass().getSimpleName());
        }
    }

    private List<File> storageRoots() {
        ArrayList<File> roots = new ArrayList<>();
        Set<String> unique = new HashSet<>();
        addRoot(roots, unique, Environment.getExternalStorageDirectory());

        StorageManager manager = (StorageManager) appContext.getSystemService(Context.STORAGE_SERVICE);
        if (manager != null) {
            try {
                for (StorageVolume volume : manager.getStorageVolumes()) {
                    String state = volume.getState();
                    if (!Environment.MEDIA_MOUNTED.equals(state) && !Environment.MEDIA_MOUNTED_READ_ONLY.equals(state)) continue;
                    File directory = volume.getDirectory();
                    if (directory != null) addRoot(roots, unique, directory);
                }
            } catch (Exception ignored) {
                // Primary shared storage remains available on devices with unusual volume APIs.
            }
        }
        return roots;
    }

    private static void addRoot(List<File> roots, Set<String> unique, File candidate) {
        if (candidate == null || !candidate.isDirectory() || !candidate.canRead()) return;
        try {
            String canonical = candidate.getCanonicalPath();
            if (unique.add(canonical)) roots.add(candidate);
        } catch (IOException | SecurityException ignored) {}
    }

    private static boolean isBlockedAndroidDirectory(File dir) {
        String name = dir.getName();
        if (!"data".equalsIgnoreCase(name) && !"obb".equalsIgnoreCase(name)) return false;
        File parent = dir.getParentFile();
        return parent != null && "Android".equalsIgnoreCase(parent.getName());
    }

    private static long readCreationTime(File file, long modified) {
        try {
            BasicFileAttributes attrs = Files.readAttributes(file.toPath(), BasicFileAttributes.class, LinkOption.NOFOLLOW_LINKS);
            long value = attrs.creationTime().toMillis();
            // Android may substitute mtime (or the Unix epoch) when birth time is unsupported.
            return value > 0 && value != modified ? value : Long.MIN_VALUE;
        } catch (Exception e) {
            return Long.MIN_VALUE;
        }
    }

    private static long readCaptureDate(File file, String ext) {
        if (isImage(ext)) return readExifDate(file);
        if (isVideo(ext)) return readVideoDate(file);
        return Long.MIN_VALUE;
    }

    private static long readExifDate(File file) {
        try {
            ExifInterface exif = new ExifInterface(file.getAbsolutePath());
            String date = exif.getAttribute(ExifInterface.TAG_DATETIME_ORIGINAL);
            if (date == null || date.trim().isEmpty()) return Long.MIN_VALUE;
            String offset = exif.getAttribute(ExifInterface.TAG_OFFSET_TIME_ORIGINAL);
            if (offset != null && !offset.trim().isEmpty()) {
                SimpleDateFormat withOffset = new SimpleDateFormat("yyyy:MM:dd HH:mm:ssXXX", Locale.US);
                withOffset.setLenient(false);
                Date parsed = parse(withOffset, date + normalizeOffset(offset));
                if (parsed != null) return parsed.getTime();
            }
            // EXIF without an offset is a wall-clock camera time. Interpret it in the device zone.
            SimpleDateFormat local = new SimpleDateFormat("yyyy:MM:dd HH:mm:ss", Locale.US);
            local.setLenient(false);
            local.setTimeZone(TimeZone.getDefault());
            Date parsed = parse(local, date);
            return parsed == null ? Long.MIN_VALUE : parsed.getTime();
        } catch (Exception e) {
            return Long.MIN_VALUE;
        }
    }

    private static String normalizeOffset(String offset) {
        String value = offset.trim();
        if (value.matches("[+-]\\d{2}:\\d{2}")) return value;
        if (value.matches("[+-]\\d{4}")) return value.substring(0, 3) + ":" + value.substring(3);
        return value;
    }

    private static long readVideoDate(File file) {
        MediaMetadataRetriever retriever = new MediaMetadataRetriever();
        try {
            retriever.setDataSource(file.getAbsolutePath());
            String raw = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DATE);
            if (raw == null || raw.trim().isEmpty()) return Long.MIN_VALUE;
            String value = raw.trim();
            String[] patterns = {
                    "yyyyMMdd'T'HHmmss.SSS'Z'", "yyyyMMdd'T'HHmmss'Z'",
                    "yyyy-MM-dd'T'HH:mm:ss.SSSXXX", "yyyy-MM-dd'T'HH:mm:ssXXX",
                    "yyyy-MM-dd HH:mm:ss", "yyyyMMdd'T'HHmmss.SSS"
            };
            for (String pattern : patterns) {
                SimpleDateFormat format = new SimpleDateFormat(pattern, Locale.US);
                format.setLenient(false);
                if (pattern.endsWith("'Z'")) format.setTimeZone(TimeZone.getTimeZone("UTC"));
                else format.setTimeZone(TimeZone.getDefault());
                Date parsed = parse(format, value);
                if (parsed != null) return parsed.getTime();
            }
            return Long.MIN_VALUE;
        } catch (Exception e) {
            return Long.MIN_VALUE;
        } finally {
            try { retriever.release(); } catch (IOException | RuntimeException ignored) {}
        }
    }

    private static Date parse(SimpleDateFormat format, String value) {
        ParsePosition position = new ParsePosition(0);
        Date date = format.parse(value, position);
        return date != null && position.getIndex() == value.length() ? date : null;
    }

    private static boolean isImage(String ext) {
        return contains(ext, "jpg", "jpeg", "tif", "tiff", "dng", "heic", "heif", "png", "webp", "avif");
    }

    private static boolean isVideo(String ext) {
        return contains(ext, "mp4", "m4v", "mkv", "mov", "avi", "3gp", "webm", "mpeg", "mpg", "ts", "mts", "m2ts", "wmv", "flv");
    }

    private static boolean contains(String value, String... values) {
        for (String v : values) if (v.equals(value)) return true;
        return false;
    }
}
