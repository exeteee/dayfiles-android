package com.dayfiles.app;

import android.webkit.MimeTypeMap;

import java.util.Locale;

final class FileTypes {
    static final String ALL = "Все файлы";
    static final String IMAGES = "Изображения";
    static final String VIDEOS = "Видео";
    static final String AUDIO = "Аудио";
    static final String DOCUMENTS = "Документы";
    static final String ARCHIVES = "Архивы";
    static final String APKS = "APK";
    static final String OTHER = "Другие";

    private FileTypes() {}

    static String extension(String name) {
        int dot = name.lastIndexOf('.');
        if (dot <= 0 || dot == name.length() - 1) return "";
        return name.substring(dot + 1).toLowerCase(Locale.ROOT);
    }

    static String kind(String ext) {
        if (in(ext, "jpg", "jpeg", "png", "gif", "bmp", "webp", "heic", "heif", "avif", "tif", "tiff", "dng", "svg", "ico", "jxl", "cr2", "nef", "arw", "orf", "rw2", "pef", "srw")) return IMAGES;
        if (in(ext, "mp4", "m4v", "mkv", "mov", "avi", "3gp", "webm", "mpeg", "mpg", "ts", "mts", "m2ts", "wmv", "flv")) return VIDEOS;
        if (in(ext, "mp3", "m4a", "aac", "wav", "flac", "ogg", "opus", "wma", "amr", "mid", "midi", "aiff")) return AUDIO;
        if (in(ext, "pdf", "doc", "docx", "docm", "dot", "dotx", "odt", "rtf", "txt", "md", "csv", "xls", "xlsx", "xlsm", "xlsb", "ods", "ppt", "pptx", "pptm", "pps", "ppsx", "odp", "epub", "mobi", "azw", "azw3", "fb2", "djvu", "djv", "tex", "ps", "xps", "pages", "numbers", "key", "html", "htm", "xml", "json", "log")) return DOCUMENTS;
        if (in(ext, "zip", "rar", "7z", "tar", "gz", "bz2", "xz", "zst", "tgz", "cab", "iso", "jar", "cbz", "cbr", "lz", "lz4", "br", "z", "deb", "rpm", "dmg", "img", "vhd", "vhdx", "vmdk")) return ARCHIVES;
        if ("apk".equals(ext) || "apks".equals(ext) || "xapk".equals(ext)) return APKS;
        return OTHER;
    }

    static String mime(String ext) {
        if (ext == null || ext.isEmpty()) return "application/octet-stream";
        if ("apk".equals(ext) || "apks".equals(ext) || "xapk".equals(ext)) return "application/vnd.android.package-archive";
        if ("md".equals(ext)) return "text/markdown";
        String type = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext);
        return type == null ? "application/octet-stream" : type;
    }

    private static boolean in(String value, String... list) {
        for (String item : list) if (item.equals(value)) return true;
        return false;
    }
}
