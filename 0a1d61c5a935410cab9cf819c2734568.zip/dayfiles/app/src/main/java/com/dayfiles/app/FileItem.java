package com.dayfiles.app;

final class FileItem {
    final String path;
    final String name;
    final String extension;
    final String kind;
    final String mime;
    final long size;
    final long modifiedMs;
    final long createdMs;
    final long exifMs;
    final boolean metadataChanged;

    FileItem(String path, String name, String extension, String kind, String mime,
             long size, long modifiedMs, long createdMs, long exifMs) {
        this(path, name, extension, kind, mime, size, modifiedMs, createdMs, exifMs, false);
    }

    FileItem(String path, String name, String extension, String kind, String mime,
             long size, long modifiedMs, long createdMs, long exifMs, boolean metadataChanged) {
        this.path = path;
        this.name = name;
        this.extension = extension;
        this.kind = kind;
        this.mime = mime;
        this.size = size;
        this.modifiedMs = modifiedMs;
        this.createdMs = createdMs;
        this.exifMs = exifMs;
        this.metadataChanged = metadataChanged;
    }
}
