package com.dayfiles.app;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.ActivityNotFoundException;
import android.database.ContentObserver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.ThumbnailUtils;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.storage.StorageManager;
import android.os.storage.StorageVolume;
import android.provider.Settings;
import android.provider.MediaStore;
import android.util.LruCache;
import android.util.Size;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    static final String DATE_MODIFIED = "Изменение";
    static final String DATE_CREATED = "Создание";
    static final String DATE_EXIF = "Съёмка";
    static final String SORT_DATE = "Дата";
    static final String SORT_NAME = "Имя";
    static final String SORT_SIZE = "Размер";
    static final String SORT_TYPE = "Тип";
    static final String SORT_PATH = "Путь";

    private static final int C_BG_LIGHT = Color.rgb(245, 246, 248);
    private static final int C_SURFACE_LIGHT = Color.WHITE;
    private static final int C_TEXT_LIGHT = Color.rgb(28, 32, 38);
    private static final int C_MUTED_LIGHT = Color.rgb(101, 109, 120);
    private static final int C_BG_DARK = Color.rgb(21, 23, 27);
    private static final int C_SURFACE_DARK = Color.rgb(31, 34, 40);
    private static final int C_TEXT_DARK = Color.rgb(239, 241, 245);
    private static final int C_MUTED_DARK = Color.rgb(166, 173, 184);
    private static final int C_ACCENT_LIGHT = Color.rgb(54, 95, 157);
    private static final int C_ACCENT_DARK = Color.rgb(138, 177, 244);

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService scanExecutor = Executors.newSingleThreadExecutor();
    private final ExecutorService queryExecutor = Executors.newSingleThreadExecutor();
    private final ExecutorService thumbnailExecutor = Executors.newFixedThreadPool(2);
    private final LruCache<String, Bitmap> thumbnailCache = new LruCache<String, Bitmap>(20 * 1024 * 1024) {
        @Override protected int sizeOf(String key, Bitmap value) { return Math.max(1, value.getByteCount()); }
    };

    private FileIndex index;
    private FileScanner scanner;
    private Calendar selectedDate = Calendar.getInstance();
    private boolean dark;
    private boolean scanRunning;
    private long lastScanStartedAt;
    private volatile boolean destroyed;
    private int queryGeneration;
    private int offset;
    private int resultTotal;
    private final ArrayList<FileItem> displayed = new ArrayList<>();
    private Runnable searchRunnable;
    private Runnable mediaRescanRunnable;
    private ContentObserver mediaObserver;

    private LinearLayout root;
    private LinearLayout resultsContainer;
    private Button dateButton;
    private Button scanButton;
    private Button themeButton;
    private Button loadMoreButton;
    private Button previousPageButton;
    private Button cancelButton;
    private TextView permissionText;
    private TextView countText;
    private TextView statusText;
    private TextView dateModeHint;
    private ProgressBar progressBar;
    private Spinner dateModeSpinner;
    private Spinner filterSpinner;
    private Spinner sortSpinner;
    private EditText searchInput;

    @Override protected void onCreate(Bundle savedInstanceState) {
        SharedPreferences prefs = getSharedPreferences("settings", MODE_PRIVATE);
        dark = prefs.getBoolean("dark", false);
        setTheme(dark ? R.style.AppTheme_Dark : R.style.AppTheme_Light);
        super.onCreate(savedInstanceState);
        index = new FileIndex(this);
        scanner = new FileScanner(this, index);
        buildUi();
        updateDateButton();
        registerMediaObserver();
        loadResults(true);
    }

    @Override protected void onResume() {
        super.onResume();
        updatePermissionState();
        if (hasAllFilesAccess() && !scanRunning &&
                (lastScanStartedAt == 0L || System.currentTimeMillis() - lastScanStartedAt > 30_000L)) {
            startScan();
        }
    }

    @Override protected void onDestroy() {
        destroyed = true;
        if (mediaObserver != null) getContentResolver().unregisterContentObserver(mediaObserver);
        if (mediaRescanRunnable != null) mainHandler.removeCallbacks(mediaRescanRunnable);
        if (scanner != null && scanRunning) scanner.cancel();
        else if (index != null) index.close();
        scanExecutor.shutdownNow();
        queryExecutor.shutdownNow();
        thumbnailExecutor.shutdownNow();
        if (index != null) index.close();
        super.onDestroy();
    }

    private void buildUi() {
        int bg = dark ? C_BG_DARK : C_BG_LIGHT;
        int surface = dark ? C_SURFACE_DARK : C_SURFACE_LIGHT;
        int text = dark ? C_TEXT_DARK : C_TEXT_LIGHT;
        int muted = dark ? C_MUTED_DARK : C_MUTED_LIGHT;
        int accent = dark ? C_ACCENT_DARK : C_ACCENT_LIGHT;

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        scroll.setBackgroundColor(bg);
        scroll.setOnApplyWindowInsetsListener((view, insets) -> {
            android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
            view.setPadding(0, bars.top, 0, bars.bottom);
            return insets;
        });
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(14), dp(16), dp(30));
        scroll.addView(root, new ScrollView.LayoutParams(-1, -2));
        setContentView(scroll);

        LinearLayout top = row();
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text("Файлы по дате", 25, text, true);
        top.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        themeButton = quietButton(dark ? "Светлая тема" : "Тёмная тема", accent);
        themeButton.setOnClickListener(v -> toggleTheme());
        top.addView(themeButton);
        root.addView(top, margin(0, 0, 0, 12));

        addLabel("ДЕНЬ ПОИСКА", muted, 11, true);
        dateButton = primaryButton("Выбрать дату", accent);
        dateButton.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
        dateButton.setPadding(dp(16), dp(13), dp(16), dp(13));
        dateButton.setOnClickListener(v -> showDatePicker());
        root.addView(dateButton, margin(0, 6, 0, 12));

        LinearLayout permissionCard = card(surface);
        permissionText = text("Для поиска по всем общим папкам Android требуется специальный доступ. Файлы остаются на устройстве.", 13, muted, false);
        permissionText.setLineSpacing(dp(2), 1f);
        permissionCard.addView(permissionText, matchWrap());
        LinearLayout actionRow = row();
        scanButton = primaryButton("Предоставить доступ", accent);
        scanButton.setOnClickListener(v -> handleScanClick());
        actionRow.addView(scanButton, new LinearLayout.LayoutParams(0, dp(48), 1));
        cancelButton = quietButton("Остановить", accent);
        cancelButton.setVisibility(View.GONE);
        cancelButton.setOnClickListener(v -> cancelScan());
        LinearLayout.LayoutParams cancelParams = new LinearLayout.LayoutParams(-2, dp(48));
        cancelParams.setMargins(dp(8), 0, 0, 0);
        actionRow.addView(cancelButton, cancelParams);
        permissionCard.addView(actionRow, margin(0, 10, 0, 0));
        root.addView(permissionCard, margin(0, 0, 0, 14));

        addLabel("ТИП ДАТЫ", muted, 11, true);
        dateModeSpinner = spinner(new String[]{"Последнее изменение", "Создание файла", "Дата съёмки (EXIF / видео)"});
        root.addView(dateModeSpinner, margin(0, 5, 0, 2));
        dateModeHint = text("Фильтр использует дату изменения файла. Остальные даты не подменяются ею.", 12, muted, false);
        root.addView(dateModeHint, margin(2, 0, 0, 12));
        dateModeSpinner.setOnItemSelectedListener(new SimpleSelection() {
            @Override public void selected(int position) {
                if (position == 0) dateModeHint.setText("Фильтр использует дату последнего изменения файла.");
                else if (position == 1) dateModeHint.setText("Показываются только файлы с отдельной временной меткой создания. Если Android её не предоставляет, дата считается недоступной.");
                else dateModeHint.setText("Используется дата съёмки из EXIF или дата из метаданных видео, если она присутствует.");
                loadResults(true);
            }
        });

        LinearLayout summary = row();
        summary.setGravity(Gravity.CENTER_VERTICAL);
        countText = text("Найдено: —", 16, text, true);
        summary.addView(countText, new LinearLayout.LayoutParams(0, -2, 1));
        statusText = text("Индекс не обновлён", 12, muted, false);
        statusText.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        summary.addView(statusText);
        root.addView(summary, margin(0, 4, 0, 7));
        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setIndeterminate(true);
        progressBar.setVisibility(View.GONE);
        root.addView(progressBar, margin(0, 0, 0, 10));

        searchInput = new EditText(this);
        searchInput.setSingleLine(true);
        searchInput.setTextSize(15);
        searchInput.setHint("Поиск по названию файла");
        searchInput.setTextColor(text);
        searchInput.setHintTextColor(muted);
        searchInput.setPadding(dp(13), dp(10), dp(13), dp(10));
        searchInput.setBackground(roundRect(surface, dp(12), dark ? 0xff424751 : 0xffe0e3e8));
        root.addView(searchInput, margin(0, 0, 0, 9));
        searchInput.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (searchRunnable != null) mainHandler.removeCallbacks(searchRunnable);
                searchRunnable = () -> loadResults(true);
                mainHandler.postDelayed(searchRunnable, 300);
            }
            @Override public void afterTextChanged(android.text.Editable s) {}
        });

        LinearLayout filterRow = row();
        filterSpinner = spinner(new String[]{FileTypes.ALL, FileTypes.IMAGES, FileTypes.VIDEOS, FileTypes.AUDIO,
                FileTypes.DOCUMENTS, FileTypes.ARCHIVES, FileTypes.APKS, FileTypes.OTHER});
        sortSpinner = spinner(new String[]{"По дате", "По названию", "По размеру", "По типу", "По расположению"});
        filterRow.addView(filterSpinner, new LinearLayout.LayoutParams(0, dp(48), 1));
        filterRow.addView(sortSpinner, new LinearLayout.LayoutParams(0, dp(48), 1));
        root.addView(filterRow, margin(0, 0, 0, 12));
        filterSpinner.setOnItemSelectedListener(new SimpleSelection() {
            @Override public void selected(int position) { loadResults(true); }
        });
        sortSpinner.setOnItemSelectedListener(new SimpleSelection() {
            @Override public void selected(int position) { loadResults(true); }
        });

        TextView listHeading = text("РЕЗУЛЬТАТЫ", 11, muted, true);
        root.addView(listHeading, margin(2, 0, 0, 6));
        resultsContainer = new LinearLayout(this);
        resultsContainer.setOrientation(LinearLayout.VERTICAL);
        root.addView(resultsContainer, matchWrap());

        LinearLayout pageControls = row();
        previousPageButton = quietButton("Предыдущая", accent);
        previousPageButton.setOnClickListener(v -> loadPreviousPage());
        previousPageButton.setVisibility(View.GONE);
        loadMoreButton = quietButton("Следующая", accent);
        loadMoreButton.setOnClickListener(v -> loadNextPage());
        loadMoreButton.setVisibility(View.GONE);
        pageControls.addView(previousPageButton, new LinearLayout.LayoutParams(0, dp(46), 1));
        LinearLayout.LayoutParams nextParams = new LinearLayout.LayoutParams(0, dp(46), 1);
        nextParams.setMargins(dp(8), 0, 0, 0);
        pageControls.addView(loadMoreButton, nextParams);
        root.addView(pageControls, margin(0, 12, 0, 0));

        TextView footer = text("Поиск выполняется локально. Содержимое файлов не копируется и не отправляется в сеть.", 12, muted, false);
        footer.setLineSpacing(dp(2), 1f);
        root.addView(footer, margin(2, 18, 2, 0));
    }


    private void registerMediaObserver() {
        mediaObserver = new ContentObserver(mainHandler) {
            @Override public void onChange(boolean selfChange) { scheduleMediaRescan(); }
            @Override public void onChange(boolean selfChange, Uri uri) { scheduleMediaRescan(); }
        };
        try {
            getContentResolver().registerContentObserver(MediaStore.Files.getContentUri("external"), true, mediaObserver);
        } catch (Exception ignored) {
            // Resume-time and manual scans still update the index if a provider omits notifications.
        }
    }

    private void scheduleMediaRescan() {
        if (mediaRescanRunnable != null) mainHandler.removeCallbacks(mediaRescanRunnable);
        mediaRescanRunnable = () -> {
            if (!destroyed && hasAllFilesAccess() && !scanRunning) startScan();
        };
        mainHandler.postDelayed(mediaRescanRunnable, 1200);
    }

    private void updatePermissionState() {
        if (hasAllFilesAccess()) {
            permissionText.setText("Доступ ко всем файлам выдан. Индексируются доступные общие папки внутреннего накопителя, SD-карт и USB-накопителей.");
            scanButton.setText(scanRunning ? "Индекс обновляется…" : "Обновить индекс");
        } else {
            permissionText.setText("Для поиска по общим папкам требуется разрешение «Доступ ко всем файлам». Android всё равно закрывает приватные каталоги других приложений (Android/data и Android/obb).");
            scanButton.setText("Предоставить доступ");
        }
    }

    private boolean hasAllFilesAccess() {
        return android.os.Build.VERSION.SDK_INT >= 30 && Environment.isExternalStorageManager();
    }

    private void handleScanClick() {
        if (!hasAllFilesAccess()) {
            try {
                Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivity(intent);
            } catch (ActivityNotFoundException e) {
                try { startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)); }
                catch (ActivityNotFoundException ignored) {
                    Toast.makeText(this, "Откройте настройки доступа к файлам вручную.", Toast.LENGTH_LONG).show();
                }
            }
        } else {
            startScan();
        }
    }

    private void startScan() {
        if (!hasAllFilesAccess() || scanRunning || destroyed) return;
        scanRunning = true;
        lastScanStartedAt = System.currentTimeMillis();
        String zoneId = TimeZone.getDefault().getID();
        SharedPreferences indexPrefs = getSharedPreferences("index_state", MODE_PRIVATE);
        String previousZone = indexPrefs.getString("metadata_zone", "");
        scanner.prepare(!previousZone.isEmpty() && !previousZone.equals(zoneId));
        themeButton.setEnabled(false);
        progressBar.setVisibility(View.VISIBLE);
        progressBar.setIndeterminate(true);
        cancelButton.setVisibility(View.VISIBLE);
        scanButton.setEnabled(false);
        statusText.setText("Подготовка…");
        updatePermissionState();
        loadResults(true);

        scanExecutor.execute(() -> {
            scanner.scan(new FileScanner.Listener() {
            @Override public void onProgress(long seen, long indexed, int inaccessible) {
                mainHandler.post(() -> {
                    if (destroyed) return;
                    progressBar.setIndeterminate(true);
                    statusText.setText("Проверено: " + seen + " · доступно: " + indexed);
                });
            }
            @Override public void onFinished(long indexed, int inaccessible, boolean cancelled, String message) {
                mainHandler.post(() -> {
                    if (destroyed) return;
                    scanRunning = false;
                    progressBar.setVisibility(View.GONE);
                    cancelButton.setVisibility(View.GONE);
                    scanButton.setEnabled(true);
                    themeButton.setEnabled(true);
                    cancelButton.setEnabled(true);
                    scanButton.setText("Обновить индекс");
                    statusText.setText("В индексе: " + index.countAll() + " · пропущено: " + inaccessible);
                    if (!cancelled && inaccessible == 0) {
                        getSharedPreferences("index_state", MODE_PRIVATE).edit()
                                .putString("metadata_zone", TimeZone.getDefault().getID()).apply();
                    }
                    Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show();
                    loadResults(true);
                });
            }
            });
            if (destroyed && index != null) index.close();
        });
    }

    private void cancelScan() {
        if (!scanRunning) return;
        scanner.cancel();
        statusText.setText("Остановка…");
        cancelButton.setEnabled(false);
    }

    private void showDatePicker() {
        DatePickerDialog dialog = new DatePickerDialog(this, (view, year, month, day) -> {
            selectedDate.set(Calendar.YEAR, year);
            selectedDate.set(Calendar.MONTH, month);
            selectedDate.set(Calendar.DAY_OF_MONTH, day);
            selectedDate.set(Calendar.HOUR_OF_DAY, 0);
            selectedDate.set(Calendar.MINUTE, 0);
            selectedDate.set(Calendar.SECOND, 0);
            selectedDate.set(Calendar.MILLISECOND, 0);
            updateDateButton();
            loadResults(true);
        }, selectedDate.get(Calendar.YEAR), selectedDate.get(Calendar.MONTH), selectedDate.get(Calendar.DAY_OF_MONTH));
        dialog.show();
    }

    private void updateDateButton() {
        if (dateButton == null) return;
        SimpleDateFormat format = new SimpleDateFormat("EEEE, d MMMM yyyy", new Locale("ru"));
        format.setTimeZone(TimeZone.getDefault());
        String value = format.format(selectedDate.getTime());
        if (!value.isEmpty()) value = value.substring(0, 1).toUpperCase(new Locale("ru")) + value.substring(1);
        dateButton.setText(value + "   ▾");
    }

    private void loadResults(boolean reset) {
        if (resultsContainer == null || destroyed) return;
        if (reset) offset = 0;
        displayed.clear();
        resultsContainer.removeAllViews();
        if (previousPageButton != null) previousPageButton.setEnabled(false);
        if (loadMoreButton != null) loadMoreButton.setEnabled(false);
        final int generation = ++queryGeneration;
        final long[] range = dayRange();
        final String mode = selectedDateMode();
        final String filter = selectedFilter();
        final String query = searchInput == null ? "" : searchInput.getText().toString();
        final String sort = selectedSort();
        final int pageOffset = offset;
        queryExecutor.execute(() -> {
            FileIndex.Page page = index.query(range[0], range[1], mode, filter, query, sort, pageOffset);
            mainHandler.post(() -> {
                if (destroyed || generation != queryGeneration) return;
                resultTotal = page.total;
                if (pageOffset >= resultTotal && pageOffset > 0) {
                    offset = 0;
                    loadResults(false);
                    return;
                }
                int currentPage = resultTotal == 0 ? 0 : (pageOffset / FileIndex.PAGE_SIZE) + 1;
                int pageCount = resultTotal == 0 ? 0 : (resultTotal + FileIndex.PAGE_SIZE - 1) / FileIndex.PAGE_SIZE;
                countText.setText("Найдено: " + resultTotal + (pageCount > 0 ? " · страница " + currentPage + "/" + pageCount : ""));
                if (page.items.isEmpty() && displayed.isEmpty()) {
                    TextView empty = text(hasAllFilesAccess() ? "За выбранный день файлов с такой датой не найдено." : "Предоставьте доступ и запустите сканирование, чтобы построить индекс.",
                            14, dark ? C_MUTED_DARK : C_MUTED_LIGHT, false);
                    empty.setPadding(dp(12), dp(20), dp(12), dp(20));
                    resultsContainer.addView(empty);
                } else {
                    for (FileItem item : page.items) {
                        displayed.add(item);
                        resultsContainer.addView(createFileRow(item), margin(0, 0, 0, 7));
                    }
                }
                previousPageButton.setVisibility(pageOffset > 0 ? View.VISIBLE : View.GONE);
                previousPageButton.setEnabled(pageOffset > 0);
                loadMoreButton.setVisibility(pageOffset + FileIndex.PAGE_SIZE < resultTotal ? View.VISIBLE : View.GONE);
                loadMoreButton.setEnabled(pageOffset + FileIndex.PAGE_SIZE < resultTotal);
                if (!scanRunning && hasAllFilesAccess() && resultTotal >= 0) {
                    statusText.setText("Индекс: " + index.countAll());
                }
            });
        });
    }

    private void loadNextPage() {
        if (offset + FileIndex.PAGE_SIZE >= resultTotal) return;
        offset += FileIndex.PAGE_SIZE;
        loadResults(false);
    }

    private void loadPreviousPage() {
        if (offset <= 0) return;
        offset = Math.max(0, offset - FileIndex.PAGE_SIZE);
        loadResults(false);
    }

    private long[] dayRange() {
        Calendar start = (Calendar) selectedDate.clone();
        start.set(Calendar.HOUR_OF_DAY, 0);
        start.set(Calendar.MINUTE, 0);
        start.set(Calendar.SECOND, 0);
        start.set(Calendar.MILLISECOND, 0);
        Calendar end = (Calendar) start.clone();
        end.add(Calendar.DAY_OF_MONTH, 1);
        return new long[]{start.getTimeInMillis(), end.getTimeInMillis()};
    }

    private String selectedDateMode() {
        int position = dateModeSpinner == null ? 0 : dateModeSpinner.getSelectedItemPosition();
        return position == 1 ? DATE_CREATED : position == 2 ? DATE_EXIF : DATE_MODIFIED;
    }

    private String selectedFilter() {
        if (filterSpinner == null || filterSpinner.getSelectedItemPosition() == 0) return FileTypes.ALL;
        return (String) filterSpinner.getSelectedItem();
    }

    private String selectedSort() {
        int position = sortSpinner == null ? 0 : sortSpinner.getSelectedItemPosition();
        switch (position) {
            case 1: return SORT_NAME;
            case 2: return SORT_SIZE;
            case 3: return SORT_TYPE;
            case 4: return SORT_PATH;
            default: return SORT_DATE;
        }
    }

    private View createFileRow(FileItem item) {
        int surface = dark ? C_SURFACE_DARK : C_SURFACE_LIGHT;
        int textColor = dark ? C_TEXT_DARK : C_TEXT_LIGHT;
        int muted = dark ? C_MUTED_DARK : C_MUTED_LIGHT;
        int accent = dark ? C_ACCENT_DARK : C_ACCENT_LIGHT;

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(10), dp(10), dp(8), dp(10));
        card.setBackground(roundRect(surface, dp(13), dark ? 0xff373c45 : 0xffe7e9ed));
        card.setClickable(true);
        card.setFocusable(true);

        FrameLayout preview = new FrameLayout(this);
        preview.setBackground(roundRect(dark ? 0xff414956 : 0xffe8edf6, dp(10), Color.TRANSPARENT));
        ImageView image = new ImageView(this);
        image.setScaleType(ImageView.ScaleType.CENTER_CROP);
        preview.addView(image, new FrameLayout.LayoutParams(dp(48), dp(48)));
        TextView typeIcon = text(shortIcon(item.kind), 10, accent, true);
        typeIcon.setGravity(Gravity.CENTER);
        preview.addView(typeIcon, new FrameLayout.LayoutParams(dp(48), dp(48)));
        card.addView(preview, new LinearLayout.LayoutParams(dp(48), dp(48)));
        if (isThumbnailCandidate(item)) loadThumbnail(item, image, typeIcon);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(10), 0, dp(5), 0);
        card.addView(content, new LinearLayout.LayoutParams(0, -2, 1));

        TextView name = text(item.name, 14, textColor, true);
        name.setMaxLines(2);
        name.setEllipsize(android.text.TextUtils.TruncateAt.END);
        content.addView(name, matchWrap());

        String ext = item.extension.isEmpty() ? "без расширения" : "." + item.extension;
        String detail = ext + " · " + formatSize(item.size) + " · " + item.kind;
        TextView details = text(detail, 11, muted, false);
        details.setMaxLines(1);
        details.setEllipsize(android.text.TextUtils.TruncateAt.END);
        content.addView(details, margin(0, 3, 0, 0));

        long matchDate = modeDate(item, selectedDateMode());
        String matched = matchDate != Long.MIN_VALUE ? "Совпадение: " + formatDateTime(matchDate) : "Дата совпадения недоступна";
        TextView dates = text(matched + "  ·  Изменён: " + formatDateTime(item.modifiedMs), 10, muted, false);
        dates.setMaxLines(2);
        dates.setEllipsize(android.text.TextUtils.TruncateAt.END);
        content.addView(dates, margin(0, 3, 0, 0));

        TextView path = text(item.path, 10, muted, false);
        path.setMaxLines(1);
        path.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
        content.addView(path, margin(0, 2, 0, 0));

        TextView share = text("↗", 21, accent, true);
        share.setGravity(Gravity.CENTER);
        share.setContentDescription("Поделиться файлом");
        card.addView(share, new LinearLayout.LayoutParams(dp(34), dp(48)));
        share.setOnClickListener(v -> shareFile(item));
        card.setOnClickListener(v -> openFile(item));
        card.setOnLongClickListener(v -> {
            Toast.makeText(this, item.path, Toast.LENGTH_LONG).show();
            return true;
        });
        return card;
    }

    private void loadThumbnail(FileItem item, ImageView view, TextView fallback) {
        Bitmap cached = thumbnailCache.get(item.path);
        if (cached != null) {
            view.setImageBitmap(cached);
            fallback.setVisibility(View.GONE);
            return;
        }
        view.setTag(item.path);
        thumbnailExecutor.execute(() -> {
            Bitmap bitmap = null;
            try {
                File file = new File(item.path);
                if (FileTypes.IMAGES.equals(item.kind)) bitmap = ThumbnailUtils.createImageThumbnail(file, new Size(96, 96), null);
                else if (FileTypes.VIDEOS.equals(item.kind)) bitmap = ThumbnailUtils.createVideoThumbnail(file, new Size(96, 96), null);
            } catch (Exception ignored) {}
            if (bitmap != null) {
                thumbnailCache.put(item.path, bitmap);
                Bitmap finalBitmap = bitmap;
                mainHandler.post(() -> {
                    if (!destroyed && item.path.equals(view.getTag())) {
                        view.setImageBitmap(finalBitmap);
                        fallback.setVisibility(View.GONE);
                    }
                });
            }
        });
    }

    private boolean isThumbnailCandidate(FileItem item) {
        return FileTypes.IMAGES.equals(item.kind) || FileTypes.VIDEOS.equals(item.kind);
    }

    private static long modeDate(FileItem item, String mode) {
        if (DATE_CREATED.equals(mode)) return item.createdMs;
        if (DATE_EXIF.equals(mode)) return item.exifMs;
        return item.modifiedMs;
    }

    private void openFile(FileItem item) {
        try {
            Uri uri = FileShareProvider.uriFor(this, new File(item.path));
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(uri, item.mime == null ? "*/*" : item.mime);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            intent.setClipData(android.content.ClipData.newUri(getContentResolver(), item.name, uri));
            startActivity(intent);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "Не найдено приложение для открытия этого файла.", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "Не удалось открыть файл: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void shareFile(FileItem item) {
        try {
            Uri uri = FileShareProvider.uriFor(this, new File(item.path));
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType(item.mime == null ? "application/octet-stream" : item.mime);
            send.putExtra(Intent.EXTRA_STREAM, uri);
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            send.setClipData(android.content.ClipData.newUri(getContentResolver(), item.name, uri));
            startActivity(Intent.createChooser(send, "Поделиться файлом"));
        } catch (Exception e) {
            Toast.makeText(this, "Не удалось подготовить файл для отправки.", Toast.LENGTH_LONG).show();
        }
    }

    private void toggleTheme() {
        dark = !dark;
        getSharedPreferences("settings", MODE_PRIVATE).edit().putBoolean("dark", dark).apply();
        recreate();
    }

    private Spinner spinner(String[] values) {
        Spinner spinner = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, values);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        return spinner;
    }

    private LinearLayout row() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.HORIZONTAL);
        return layout;
    }

    private LinearLayout card(int color) {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(14), dp(14), dp(14), dp(14));
        layout.setBackground(roundRect(color, dp(14), dark ? 0xff363b44 : 0xffe4e7ec));
        return layout;
    }

    private void addLabel(String value, int color, int size, boolean bold) {
        root.addView(text(value, size, color, bold), margin(2, 0, 0, 0));
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return view;
    }

    private Button primaryButton(String value, int accent) {
        Button button = new Button(this);
        button.setText(value);
        button.setTextSize(14);
        button.setAllCaps(false);
        button.setTextColor(dark ? Color.rgb(18, 27, 42) : Color.WHITE);
        button.setBackground(roundRect(accent, dp(12), Color.TRANSPARENT));
        return button;
    }

    private Button quietButton(String value, int accent) {
        Button button = new Button(this);
        button.setText(value);
        button.setTextSize(13);
        button.setAllCaps(false);
        button.setTextColor(accent);
        button.setBackground(roundRect(dark ? 0xff303640 : 0xffe9edf4, dp(11), Color.TRANSPARENT));
        return button;
    }

    private GradientDrawable roundRect(int color, int radius, int stroke) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(radius);
        if (stroke != Color.TRANSPARENT) drawable.setStroke(dp(1), stroke);
        return drawable;
    }

    private LinearLayout.LayoutParams margin(int left, int top, int right, int bottom) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.setMargins(dp(left), dp(top), dp(right), dp(bottom));
        return params;
    }

    private LinearLayout.LayoutParams matchWrap() { return new LinearLayout.LayoutParams(-1, -2); }
    private int dp(float value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }

    private String shortIcon(String kind) {
        if (FileTypes.IMAGES.equals(kind)) return "IMG";
        if (FileTypes.VIDEOS.equals(kind)) return "VID";
        if (FileTypes.AUDIO.equals(kind)) return "AUD";
        if (FileTypes.DOCUMENTS.equals(kind)) return "DOC";
        if (FileTypes.ARCHIVES.equals(kind)) return "ZIP";
        if (FileTypes.APKS.equals(kind)) return "APK";
        return "FILE";
    }

    private String formatSize(long bytes) {
        if (bytes < 1024) return bytes + " Б";
        if (bytes < 1024L * 1024) return String.format(Locale.getDefault(), "%.1f КБ", bytes / 1024.0);
        if (bytes < 1024L * 1024 * 1024) return String.format(Locale.getDefault(), "%.1f МБ", bytes / (1024.0 * 1024));
        return String.format(Locale.getDefault(), "%.2f ГБ", bytes / (1024.0 * 1024 * 1024));
    }

    private String formatDateTime(long millis) {
        DateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault());
        format.setTimeZone(TimeZone.getDefault());
        return format.format(new Date(millis));
    }

    private abstract static class SimpleSelection implements AdapterView.OnItemSelectedListener {
        @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) { selected(position); }
        @Override public void onNothingSelected(AdapterView<?> parent) {}
        public abstract void selected(int position);
    }
}
