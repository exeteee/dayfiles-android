package com.dayfiles.app;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

final class FileIndex extends SQLiteOpenHelper {
    static final int PAGE_SIZE = 50;
    private static final String DB_NAME = "dayfiles-index.db";
    private static final int DB_VERSION = 1;

    static final class Cached {
        final long size, modifiedMs, createdMs, exifMs;
        Cached(long size, long modifiedMs, long createdMs, long exifMs) {
            this.size = size; this.modifiedMs = modifiedMs; this.createdMs = createdMs; this.exifMs = exifMs;
        }
    }

    static final class Page {
        final int total;
        final List<FileItem> items;
        Page(int total, List<FileItem> items) { this.total = total; this.items = items; }
    }

    FileIndex(Context context) { super(context, DB_NAME, null, DB_VERSION); }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE files (" +
                "path TEXT PRIMARY KEY NOT NULL, name TEXT NOT NULL, ext TEXT NOT NULL, " +
                "kind TEXT NOT NULL, mime TEXT NOT NULL, size INTEGER NOT NULL, " +
                "modified_ms INTEGER NOT NULL, created_ms INTEGER NOT NULL, exif_ms INTEGER NOT NULL, " +
                "scan_id INTEGER NOT NULL)");
        db.execSQL("CREATE INDEX idx_files_modified ON files(modified_ms)");
        db.execSQL("CREATE INDEX idx_files_created ON files(created_ms)");
        db.execSQL("CREATE INDEX idx_files_exif ON files(exif_ms)");
        db.execSQL("CREATE INDEX idx_files_name ON files(name COLLATE NOCASE)");
        db.execSQL("CREATE INDEX idx_files_size ON files(size)");
        db.execSQL("CREATE INDEX idx_files_kind ON files(kind)");
        db.execSQL("CREATE INDEX idx_files_path ON files(path COLLATE NOCASE)");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS files");
        onCreate(db);
    }

    synchronized Cached getCached(String path) {
        SQLiteDatabase db = getReadableDatabase();
        try (Cursor c = db.rawQuery("SELECT size, modified_ms, created_ms, exif_ms FROM files WHERE path=?", new String[]{path})) {
            if (!c.moveToFirst()) return null;
            return new Cached(c.getLong(0), c.getLong(1), c.getLong(2), c.getLong(3));
        }
    }

    synchronized void upsertBatch(List<FileItem> items, long scanId) {
        if (items.isEmpty()) return;
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            for (FileItem item : items) {
                ContentValues seen = new ContentValues();
                seen.put("scan_id", scanId);
                int updated;
                if (item.metadataChanged) {
                    ContentValues values = fullValues(item, scanId);
                    updated = db.update("files", values, "path=?", new String[]{item.path});
                    if (updated == 0) db.insert("files", null, values);
                } else {
                    updated = db.update("files", seen, "path=?", new String[]{item.path});
                    if (updated == 0) db.insert("files", null, fullValues(item, scanId));
                }
            }
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }


    private static ContentValues fullValues(FileItem item, long scanId) {
        ContentValues v = new ContentValues();
        v.put("path", item.path);
        v.put("name", item.name);
        v.put("ext", item.extension);
        v.put("kind", item.kind);
        v.put("mime", item.mime);
        v.put("size", item.size);
        v.put("modified_ms", item.modifiedMs);
        v.put("created_ms", item.createdMs);
        v.put("exif_ms", item.exifMs);
        v.put("scan_id", scanId);
        return v;
    }

    synchronized void removeUnseen(long scanId) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete("files", "scan_id<>?", new String[]{String.valueOf(scanId)});
    }

    synchronized int countAll() {
        try (Cursor c = getReadableDatabase().rawQuery("SELECT COUNT(*) FROM files", null)) {
            return c.moveToFirst() ? c.getInt(0) : 0;
        }
    }

    synchronized Page query(long startMs, long endMs, String dateMode, String filter,
                            String search, String sort, int offset) {
        String dateColumn;
        switch (dateMode) {
            case MainActivity.DATE_CREATED: dateColumn = "created_ms"; break;
            case MainActivity.DATE_EXIF: dateColumn = "exif_ms"; break;
            default: dateColumn = "modified_ms";
        }

        StringBuilder where = new StringBuilder(dateColumn).append(" >= ? AND ")
                .append(dateColumn).append(" < ?");
        ArrayList<String> args = new ArrayList<>();
        args.add(String.valueOf(startMs));
        args.add(String.valueOf(endMs));

        if (filter != null && !FileTypes.ALL.equals(filter)) {
            where.append(" AND kind=?");
            args.add(filter);
        }
        if (search != null && !search.trim().isEmpty()) {
            where.append(" AND name LIKE ? ESCAPE '\\' COLLATE NOCASE");
            args.add("%" + escapeLike(search.trim()) + "%");
        }

        String order;
        switch (sort) {
            case MainActivity.SORT_NAME: order = "name COLLATE NOCASE ASC, path ASC"; break;
            case MainActivity.SORT_SIZE: order = "size DESC, name COLLATE NOCASE ASC"; break;
            case MainActivity.SORT_TYPE: order = "kind ASC, ext ASC, name COLLATE NOCASE ASC"; break;
            case MainActivity.SORT_PATH: order = "path COLLATE NOCASE ASC"; break;
            default: order = dateColumn + " DESC, name COLLATE NOCASE ASC";
        }

        SQLiteDatabase db = getReadableDatabase();
        String[] selectionArgs = args.toArray(new String[0]);
        int total;
        try (Cursor c = db.rawQuery("SELECT COUNT(*) FROM files WHERE " + where, selectionArgs)) {
            total = c.moveToFirst() ? c.getInt(0) : 0;
        }

        ArrayList<FileItem> result = new ArrayList<>();
        String sql = "SELECT path,name,ext,kind,mime,size,modified_ms,created_ms,exif_ms FROM files WHERE " +
                where + " ORDER BY " + order + " LIMIT " + PAGE_SIZE + " OFFSET " + Math.max(0, offset);
        try (Cursor c = db.rawQuery(sql, selectionArgs)) {
            while (c.moveToNext()) {
                result.add(new FileItem(c.getString(0), c.getString(1), c.getString(2), c.getString(3),
                        c.getString(4), c.getLong(5), c.getLong(6), c.getLong(7), c.getLong(8)));
            }
        }
        return new Page(total, result);
    }

    private static String escapeLike(String s) {
        return s.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_");
    }
}
