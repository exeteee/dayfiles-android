package com.dayfiles.app;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.os.Environment;
import android.os.storage.StorageManager;
import android.os.storage.StorageVolume;
import android.provider.OpenableColumns;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public final class FileShareProvider extends ContentProvider {
    private String authority;

    @Override public boolean onCreate() {
        authority = getContext() == null ? "" : getContext().getPackageName() + ".files";
        return true;
    }

    static Uri uriFor(Context context, File file) throws IOException {
        String canonical = file.getCanonicalPath();
        if (!file.isFile() || !file.canRead() || !isInsideSharedStorage(context, canonical) || isBlocked(canonical)) {
            throw new FileNotFoundException("Файл недоступен для передачи");
        }
        return new Uri.Builder().scheme("content")
                .authority(context.getPackageName() + ".files")
                .appendPath("open")
                .appendQueryParameter("p", canonical)
                .build();
    }

    @Override public String getType(Uri uri) {
        File file = resolve(uri);
        if (file == null) return "application/octet-stream";
        return FileTypes.mime(FileTypes.extension(file.getName()));
    }

    @Override public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) {
        File file = resolve(uri);
        if (file == null) return null;
        String[] columns = projection == null ? new String[]{OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE} : projection;
        MatrixCursor cursor = new MatrixCursor(columns);
        Object[] row = new Object[columns.length];
        for (int i = 0; i < columns.length; i++) {
            if (OpenableColumns.DISPLAY_NAME.equals(columns[i])) row[i] = file.getName();
            else if (OpenableColumns.SIZE.equals(columns[i])) row[i] = file.length();
            else row[i] = null;
        }
        cursor.addRow(row);
        return cursor;
    }

    @Override public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException {
        if (!"r".equals(mode)) throw new FileNotFoundException("Разрешено только чтение");
        File file = resolve(uri);
        if (file == null) throw new FileNotFoundException("Файл не найден или недоступен");
        try {
            return ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY);
        } catch (IOException e) {
            throw new FileNotFoundException(e.getMessage());
        }
    }

    private File resolve(Uri uri) {
        if (uri == null || !"open".equals(uri.getLastPathSegment())) return null;
        String path = uri.getQueryParameter("p");
        if (path == null) return null;
        try {
            File file = new File(path).getCanonicalFile();
            if (!file.isFile() || !file.canRead() || isBlocked(file.getPath()) ||
                    !isInsideSharedStorage(getContext(), file.getPath())) return null;
            return file;
        } catch (Exception e) {
            return null;
        }
    }

    private static boolean isBlocked(String path) {
        String normalized = path.replace('\\', '/');
        return normalized.contains("/Android/data/") || normalized.endsWith("/Android/data") ||
                normalized.contains("/Android/obb/") || normalized.endsWith("/Android/obb");
    }

    private static boolean isInsideSharedStorage(Context context, String path) {
        List<File> roots = new ArrayList<>();
        roots.add(Environment.getExternalStorageDirectory());
        try {
            StorageManager manager = (StorageManager) context.getSystemService(Context.STORAGE_SERVICE);
            if (manager != null) {
                for (StorageVolume volume : manager.getStorageVolumes()) {
                    String state = volume.getState();
                    if ((Environment.MEDIA_MOUNTED.equals(state) || Environment.MEDIA_MOUNTED_READ_ONLY.equals(state)) && volume.getDirectory() != null) {
                        roots.add(volume.getDirectory());
                    }
                }
            }
        } catch (Exception ignored) {}

        for (File root : roots) {
            if (root == null) continue;
            try {
                String base = root.getCanonicalPath();
                if (path.equals(base) || path.startsWith(base + File.separator)) return true;
            } catch (IOException | SecurityException ignored) {}
        }
        return false;
    }

    @Override public Uri insert(Uri uri, ContentValues values) { throw new UnsupportedOperationException(); }
    @Override public int delete(Uri uri, String selection, String[] selectionArgs) { throw new UnsupportedOperationException(); }
    @Override public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) { throw new UnsupportedOperationException(); }
}
